#!/bin/bash
/opt/usr/nx-ks/popup_timeout "Hello, from Custom Checkbox." 4
