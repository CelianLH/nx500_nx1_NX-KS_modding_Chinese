#!/bin/bash
/opt/usr/nx-ks/popup_timeout "Custom Checkbox - closing." 4
